# 武汉大学硕博士毕业论文 LaTeX 模板

武汉大学硕(博)士学位论文的 LaTeX 模版，支持 CTeX 2.9 版本, 使用 XeLaTeX 编译。 

## 版权信息

**作者主页有更新（包含本科生毕业论文模板），推荐大家到作者主页下载最新的版本！**

```
黄正华<huangzh@whu.edu.cn>

Home Page: http://aff.whu.edu.cn/huangzh/
```

## 预览

![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-01.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-02.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-03.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-04.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-05.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-06.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-07.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-08.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-09.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-10.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-11.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-12.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-13.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-14.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-15.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-16.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-17.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-18.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-19.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-20.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-21.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-22.png)  
![](https://github.com/DeathKing/LaTeX-Template-Cn/blob/master/Preview/whubook-23.png)  
