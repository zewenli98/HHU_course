# 中文论文通用模版

一个高质量的 LaTeX + CJK 模板，只针对 A4 纸的中文论文。

## 版权信息

```
Ver 1.01 By rabbitbug @ www.ctex.org
Ver 1.0 by oLo @ bbs.ustc.edu.cn

You can mofify it and distribute it freely:)
```

## 预览

![](https://raw.githubusercontent.com/DeathKing/LaTeX-Template-Cn/master/Preview/CHN-PaperTemplate-1.png)
![](https://raw.githubusercontent.com/DeathKing/LaTeX-Template-Cn/master/Preview/CHN-PaperTemplate-2.png)
![](https://raw.githubusercontent.com/DeathKing/LaTeX-Template-Cn/master/Preview/CHN-PaperTemplate-3.png)
